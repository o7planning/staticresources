Using in example:

http://o7planning.org/e/12787/android-textwatcher-credit-card
Using in example:

http://o7planning.org/en/12787/android-textwatcher-credit-card